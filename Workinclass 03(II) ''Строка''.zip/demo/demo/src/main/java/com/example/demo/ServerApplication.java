package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}
}

/*Задание. Создать запрос, по которому можно передать строку, а результатом будет строка в верхнем регистре.*/

// Образец запроса в комментарии контроллера StrController (расположен в папке controllers)