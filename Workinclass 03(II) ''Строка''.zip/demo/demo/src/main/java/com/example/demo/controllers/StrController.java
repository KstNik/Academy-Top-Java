package com.example.demo.controllers;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StrController {
    @GetMapping("/")
    public String toUpperCase(
            @RequestParam(value = "str", defaultValue = "0") String str) {
        return str.toUpperCase();
    }
}

// В строке браузера набрать: localhost:8080/?str=Snow, загрузится странице с надписью SNOW