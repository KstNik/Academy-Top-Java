package com.example.algebraicequation.controller;

import com.example.algebraicequation.service.EquationSolver;
import com.example.algebraicequation.service.EquationStandardizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/")
public class EquationController {

    @Autowired
    private EquationSolver equationSolver;

    @Autowired
    private EquationStandardizer equationStandardizer;

    @GetMapping
    public String showForm(Model model) {
        model.addAttribute("equation", "");
        model.addAttribute("standardizedEquation", "");
        return "index";
    }

    @PostMapping("/standardize")
    public String standardizeEquation(@RequestParam String equation, Model model) {
        try {
            String standardizedEquation = equationStandardizer.standardize(equation);
            model.addAttribute("standardizedEquation", standardizedEquation);
            model.addAttribute("equation", equation);
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", "Уравнение введено некорректно");
        }
        return "index";
    }

    @PostMapping("/solve")
    public String solveEquation(@RequestParam String equation, @RequestParam int precision, Model model) {
        try {
            // Преобразование уравнения к стандартному виду
            String standardizedEquation = equationStandardizer.standardize(equation);
            model.addAttribute("standardizedEquation", standardizedEquation);

            // Извлечение коэффициентов из уравнения
            double[] coefficients = parseEquation(standardizedEquation);

            // Решение уравнения
            List<String> roots = equationSolver.solveEquation(coefficients.length - 1, coefficients, precision);
            model.addAttribute("roots", roots);
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", "Уравнение введено некорректно");
        }
        return "index";
    }

    private double[] parseEquation(String equation) {
        // Удаление пробелов и знака равенства
        equation = equation.replaceAll("\\s", "").replace("=0", "");

        // Разбивка уравнения на части
        String[] terms = equation.split("(?=[+-])");

        // Определение максимальной степени
        int maxDegree = 0;
        for (String term : terms) {
            if (term.contains("x^")) {
                int degree = Integer.parseInt(term.split("x\\^")[1]);
                if (degree > maxDegree) {
                    maxDegree = degree;
                }
            } else if (term.contains("x")) {
                if (1 > maxDegree) {
                    maxDegree = 1;
                }
            }
        }

        // Создание массива коэффициентов
        double[] coefficients = new double[maxDegree + 1];

        // Заполнение массива коэффициентов
        for (String term : terms) {
            if (term.contains("x^")) {
                String[] parts = term.split("x\\^");
                int degree = Integer.parseInt(parts[1]);
                double coeff = parts[0].isEmpty() || parts[0].equals("+") ? 1 : parts[0].equals("-") ? -1 : Double.parseDouble(parts[0].replace(",", "."));
                coefficients[degree] = coeff;
            } else if (term.contains("x")) {
                String coeffStr = term.replace("x", "");
                double coeff = coeffStr.isEmpty() || coeffStr.equals("+") ? 1 : coeffStr.equals("-") ? -1 : Double.parseDouble(coeffStr.replace(",", "."));
                coefficients[1] = coeff;
            } else {
                coefficients[0] = Double.parseDouble(term.replace(",", "."));
            }
        }

        return coefficients;
    }
}