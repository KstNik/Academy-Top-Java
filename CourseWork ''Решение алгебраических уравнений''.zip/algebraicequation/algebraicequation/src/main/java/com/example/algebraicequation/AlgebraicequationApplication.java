package com.example.algebraicequation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgebraicequationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgebraicequationApplication.class, args);
	}

}

// При создании проекта на сайте https://start.spring.io добавлены зависимости (кнопка ADD DEPENDENCIES): Spring Web, Thimeleaf, Spring Boot DevTools
// Для запуска приложения набрать в адресной строке браузера: localhost:8080

// Задание. Реализовать решение алгебраических уравнений с одной переменной.