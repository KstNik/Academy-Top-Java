package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}

/*Задание 1. Передать на сайт число и объект.
Задание 2. Изменять заливку фона для чётных и нечётных чисел.*/

// Для загрузки страницы в строке браузера набрать: localhost:8080
// При создании проекта на сайте https://start.spring.io добавлены зависимости (кнопка ADD DEPENDENCIES): Sprint Web, Thimeleaf и Spring Boot DevTools