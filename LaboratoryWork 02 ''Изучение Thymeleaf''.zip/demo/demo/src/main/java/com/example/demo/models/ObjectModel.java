package com.example.demo.models;

public class ObjectModel {
    public String name;
    public int agility;
    public int strength;
    public int intelligence;
    public String genre;
}