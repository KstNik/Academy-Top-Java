package com.example.demo.controllers;

import com.example.demo.models.ObjectModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Random;

// При объявлении класса, как Controller его методы выступают в роли определения View-html представлений

@Controller
public class ViewController {

    @GetMapping("/")
    public String home() {
        // Вернуть файл с названием index.html
        return "index";
    }

    @GetMapping("/model/form/number")
    public String modelFromNumber() {
        return "models/form/number";
    }

    @GetMapping("/model/form/object")
    public String modelFromObject() {
        return "models/form/object";
    }

    @PostMapping("/model/view/number")
    public String modelViewNumber(@RequestParam(name="number", defaultValue="0") int value, Model model) {
        // Добавление в модель свойства "value" Со значением параметра запроса
        model.addAttribute("value", value);
        return "models/view/number";
    }

    @PostMapping("/model/view/object")
    public String modelViewObject(
        @RequestParam(name="name", defaultValue="-") String name,
        @RequestParam(name="agility", defaultValue="0") int agility,
        @RequestParam(name="strength", defaultValue="0") int strength,
        @RequestParam(name="intelligence", defaultValue="0") int intelligence,
        @RequestParam(name="genre", defaultValue="M") String genre,
        Model model
    ) {
        /*
        model.addAttribute("name", name);
        model.addAttribute("agility", agility);
        model.addAttribute("strength", strength);
        model.addAttribute("intelligence", intelligence);
        model.addAttribute("genre", genre);
        */
        ObjectModel data = new ObjectModel();
        data.agility = agility;
        data.genre = genre;
        data.name = name;
        data.intelligence = intelligence;
        data.strength = strength;
        model.addAttribute("model", data);

        return "models/view/object";
    }

    @GetMapping("/interpolation/if")
    public String ThymeleafIf(Model model) {
        model.addAttribute("value", new Random().nextInt());

        return "interpolation/if";
    }

    @GetMapping("/interpolation/switch")
    public String ThymeleafSwitch(Model model) {
        model.addAttribute("name", "Noname");
        model.addAttribute(
                "genge",
                new Random().nextInt() % 2 == 0 ? "M" : "F"
        );
        return "interpolation/switch";
    }

    @GetMapping("/interpolation/array")
    public String ThymeleafArray(Model model) {
        Random rand = new Random();
        int[] mas = new int[Math.abs(rand.nextInt()) % 10 + 7];
        for(int i = 0; i < mas.length; ++i) {
            mas[i] = rand.nextInt();
        }
        model.addAttribute("array", mas);
        return "interpolation/array";
    }
}