package com.example.demo.controller;

import com.example.demo.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.Arrays;
import java.util.List;

@Controller
public class UserController {
    @GetMapping("/users")
    public String getUsers(Model model) {
        // Создание списка пользователей
        List<User> users = Arrays.asList(
                new User("Alice", 25, "alice@example.com"),
                new User("Bob", 30, "bob@example.com"),
                new User("Charlie", 22, "charlie@example.com")
        );
        model.addAttribute("users", users);
        return "users";
    }
}