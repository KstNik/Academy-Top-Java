package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}

/*Задание. Создайте Spring Boot приложение, которое отображает список пользователей на веб-странице с использованием Thymeleaf. Каждый пользователь имеет имя, возраст и электронную почту. Данные пользователей должны быть переданы в шаблон и отображены в таблице.*/

// Dependencies: Spring Web; Thymeleaf; Spring Boot DevTools
// Для запуска приложения набрать запрос в адресной строке браузера: localhost:8080/users