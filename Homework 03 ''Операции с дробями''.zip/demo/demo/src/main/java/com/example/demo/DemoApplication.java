package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}

// При создании проекта на сайте https://start.spring.io добавлены зависимости (кнопка ADD DEPENDENCIES): Spring Web и Spring Web Services

/*Задание 1. Создайте RESTful сервис, который инкапсулирует операции по работе с дробями. У дроби есть числитель и знаменатель. Вам необходимо реализовать проверку является ли дробь правильной.
Для выполнения набрать запрос в адресной строке браузера: localhost:8080/fractions/isProper?numerator=3&denominator=4

Задание 2. Добавьте к первому заданию операцию по сокращению дроби.
Для выполнения набрать запрос в адресной строке браузера: localhost:8080/fractions/reduce?numerator=6&denominator=9

Задание 3. Добавьте ко второму заданию операцию по сложению двух дробей.
Для выполнения набрать запрос в адресной строке браузера: localhost:8080/fractions/add?num1=1&den1=2&num2=1&den2=3

Задание 4. Добавьте к третьему заданию операцию по вычитанию двух дробей.
Для выполнения набрать запрос в адресной строке браузера: localhost:8080/fractions/subtract?num1=3&den1=4&num2=1&den2=6

Задание 5. Добавьте к четвёртому заданию операцию по умножению двух дробей.
Для выполнения набрать запрос в адресной строке браузера: localhost:8080/fractions/multiply?num1=3&den1=4&num2=2&den2=5

Задание 6. Добавьте к пятому заданию операцию по делению двух дробей.
Для выполнения набрать запрос в адресной строке браузера: localhost:8080/fractions/divide?num1=3&den1=4&num2=2&den2=5*/