package com.example.demo.controller;

import com.example.demo.model.Fraction;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/fractions")
public class FractionController {

    @GetMapping("/isProper")
    public boolean isProper(@RequestParam int numerator, @RequestParam int denominator) {
        Fraction fraction = new Fraction(numerator, denominator);
        return fraction.isProper();
    }

    @GetMapping("/reduce")
    public Fraction reduce(@RequestParam int numerator, @RequestParam int denominator) {
        int gcd = gcd(numerator, denominator);
        return new Fraction(numerator / gcd, denominator / gcd);
    }

    private int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    @GetMapping("/add")
    public Fraction add(@RequestParam int num1, @RequestParam int den1,
                        @RequestParam int num2, @RequestParam int den2) {
        int numerator = num1 * den2 + num2 * den1;
        int denominator = den1 * den2;
        return reduce(numerator, denominator);
    }

    @GetMapping("/subtract")
    public Fraction subtract(@RequestParam int num1, @RequestParam int den1,
                             @RequestParam int num2, @RequestParam int den2) {
        int numerator = num1 * den2 - num2 * den1;
        int denominator = den1 * den2;
        return reduce(numerator, denominator);
    }

    @GetMapping("/multiply")
    public Fraction multiply(@RequestParam int num1, @RequestParam int den1,
                             @RequestParam int num2, @RequestParam int den2) {
        int numerator = num1 * num2;
        int denominator = den1 * den2;
        return reduce(numerator, denominator);
    }

    @GetMapping("/divide")
    public Fraction divide(@RequestParam int num1, @RequestParam int den1,
                           @RequestParam int num2, @RequestParam int den2) {
        if (num2 == 0) {
            throw new IllegalArgumentException("Cannot divide by a fraction with a numerator of 0.");
        }
        int numerator = num1 * den2;              // Числитель результата деления
        int denominator = den1 * num2;            // Знаменатель результата деления
        return reduce(numerator, denominator);    // Сокращаем дробь
    }
}