package com.example.fractionapp.controller;

import com.example.fractionapp.model.Fraction;
import com.example.fractionapp.service.FractionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/fractions")
public class FractionController {

    @Autowired
    private FractionService fractionService;

    @GetMapping
    public String fractionPage() {
        return "fractions";
    }

    @PostMapping("/check")
    public String checkFraction(@RequestParam int numerator, @RequestParam int denominator, Model model) {
        Fraction fraction = new Fraction(numerator, denominator);
        model.addAttribute("result", fractionService.checkFraction(fraction));
        return "fractions";
    }

    @PostMapping("/reduce")
    public String reduceFraction(@RequestParam int numerator, @RequestParam int denominator, Model model) {
        Fraction fraction = new Fraction(numerator, denominator);
        Fraction reduced = fractionService.reduceFraction(fraction);
        model.addAttribute("result", reduced.toString());
        return "fractions";
    }

    @PostMapping("/operation")
    public String operateFractions(
            @RequestParam int num1, @RequestParam int den1,
            @RequestParam int num2, @RequestParam int den2,
            @RequestParam String operation, Model model) {
        Fraction f1 = new Fraction(num1, den1);
        Fraction f2 = new Fraction(num2, den2);
        Fraction result;
        switch (operation) {
            case "add":
                result = fractionService.addFractions(f1, f2);
                break;
            case "subtract":
                result = fractionService.subtractFractions(f1, f2);
                break;
            case "multiply":
                result = fractionService.multiplyFractions(f1, f2);
                break;
            case "divide":
                result = fractionService.divideFractions(f1, f2);
                break;
            default:
                throw new IllegalArgumentException("Invalid operation");
        }
        result.reduce();
        model.addAttribute("result", result.toString());
        return "fractions";
    }
}