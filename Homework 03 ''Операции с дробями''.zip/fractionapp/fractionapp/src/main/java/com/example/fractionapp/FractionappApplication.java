package com.example.fractionapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FractionappApplication {
	public static void main(String[] args) {
		SpringApplication.run(FractionappApplication.class, args);
	}
}

// При создании проекта на сайте https://start.spring.io добавлены зависимости (кнопка ADD DEPENDENCIES): Sprint Web и Thimeleaf

// Для запуска приложения набрать в адресной строке браузера: localhost:8080/fractions

/*Задание 7. Создайте SOAP сервис, который инкапсулирует операции по работе с дробями. У дроби есть числитель и знаменатель. Требуется реализовать такие операции:
 - Проверка на правильность дроби;
 - Сокращение дроби;
 - Сложение;
 - Вычитание;
 - Умножение;
 - Деление.*/