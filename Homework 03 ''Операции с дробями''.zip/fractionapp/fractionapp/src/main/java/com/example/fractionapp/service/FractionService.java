package com.example.fractionapp.service;

import com.example.fractionapp.model.Fraction;
import org.springframework.stereotype.Service;

@Service
public class FractionService {

    public String checkFraction(Fraction fraction) {
        return fraction.getNumerator() < fraction.getDenominator() ? "Правильная" : "Неправильная";
    }

    public Fraction reduceFraction(Fraction fraction) {
        fraction.reduce();
        return fraction;
    }

    public Fraction addFractions(Fraction f1, Fraction f2) {
        int numerator = f1.getNumerator() * f2.getDenominator() + f2.getNumerator() * f1.getDenominator();
        int denominator = f1.getDenominator() * f2.getDenominator();
        return new Fraction(numerator, denominator);
    }

    public Fraction subtractFractions(Fraction f1, Fraction f2) {
        int numerator = f1.getNumerator() * f2.getDenominator() - f2.getNumerator() * f1.getDenominator();
        int denominator = f1.getDenominator() * f2.getDenominator();
        return new Fraction(numerator, denominator);
    }

    public Fraction multiplyFractions(Fraction f1, Fraction f2) {
        int numerator = f1.getNumerator() * f2.getNumerator();
        int denominator = f1.getDenominator() * f2.getDenominator();
        return new Fraction(numerator, denominator);
    }

    public Fraction divideFractions(Fraction f1, Fraction f2) {
        int numerator = f1.getNumerator() * f2.getDenominator();
        int denominator = f1.getDenominator() * f2.getNumerator();
        return new Fraction(numerator, denominator);
    }
}
