package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}
}

/*Задание 1. Создать web-страницу, выводящую приветствие пользователя.
  Задание 2. Создать web-страницу, выполняющую арифметические операции.

Запросы описаны в комментариях контроллеров ApiController и BaseController (расположены в папке controllers)*/