package com.example.demo.controllers;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApiController {
    // Для вычисления суммы 2-х чисел набрать в адресной строке браузера: localhost:8080/api/sum?a=8&b=5
    @GetMapping("/api/sum")
    public int sum(
            @RequestParam(value = "a", defaultValue = "0") int a,
            @RequestParam(value = "b", defaultValue = "0") int b) {
        return a + b;
    }
    // Для вычисления произведения 2-х чисел набрать в адресной строке браузера: localhost:8080/api/mul?a=8&b=5
    @GetMapping("/api/mul")
    public int mul(
            @RequestParam(value = "a", defaultValue = "0") int a,
            @RequestParam(value = "b", defaultValue = "0") int b) {
        return a * b;
    }
    // Для вычисления частного 2-х чисел набрать в адресной строке браузера: localhost:8080/api/div?a=8&b=5
    @GetMapping("/api/div")
    public int div(
            @RequestParam(value = "a", defaultValue = "0") int a,
            @RequestParam(value = "b", defaultValue = "0") int b) {
        return a / b;
    }
    // Для вычисления разности 2-х чисел набрать в адресной строке браузера: localhost:8080/api/sub?a=8&b=5
    @GetMapping("/api/sub")
    public int sub(
            @RequestParam(value = "a", defaultValue = "0") int a,
            @RequestParam(value = "b", defaultValue = "0") int b) {
        return a - b;
    }
}