package com.example.demo.controllers;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BaseController {
    @GetMapping ("/")
    public String request(
            @RequestParam(value = "name", defaultValue = "noname") String name,
            @RequestParam(value = "surname") String surname) {
        return "Hello " + name + " " + surname + "!";
    }
}
// В строке браузера набрать: localhost:8080/?name=Ivan&surname=Ivanov, – загрузится странице с надписью Hello Ivan Ivanov!