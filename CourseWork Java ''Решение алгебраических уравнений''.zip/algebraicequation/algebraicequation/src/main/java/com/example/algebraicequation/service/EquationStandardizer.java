package com.example.algebraicequation.service;

import org.matheclipse.core.eval.ExprEvaluator;
import org.matheclipse.core.interfaces.IExpr;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EquationStandardizer {

    public String standardize(String equation) {
        try {
            // Замена запятых на точки
            equation = equation.replace(",", ".");
            // Удаляем пробелы
            equation = equation.replaceAll("\\s", "");

            // Проверка, что уравнение содержит ровно один знак "="
            String[] parts = equation.split("=");
            if (parts.length != 2) {
                throw new IllegalArgumentException("Уравнение должно содержать один знак '='");
            }

            String left = parts[0];
            String right = parts[1];

            // Нахождение знаменателей в левой и правой частях
            String leftNumerator = left.contains("/") ? left.split("/")[0] : left;
            String leftDenominator = left.contains("/") ? left.split("/")[1] : "1";

            String rightNumerator = right.contains("/") ? right.split("/")[0] : right;
            String rightDenominator = right.contains("/") ? right.split("/")[1] : "1";

            // Умножение обеих частей на знаменатели для избавления от деления
            String fullEquation = "(" + leftNumerator + ")*(" + rightDenominator + ")-(" + rightNumerator + ")*(" + leftDenominator + ")";

            // Создание экземпляра парсера
            ExprEvaluator evaluator = new ExprEvaluator();

            // Парсинг и упрощение уравнения
            IExpr expr = evaluator.parse(fullEquation);
            IExpr expandedExpr = evaluator.eval("Expand[" + expr + "]");

            // Сортировка полинома по степеням переменной x
            IExpr sortedExpr = evaluator.eval("Collect[" + expandedExpr + ", x]");

            // Форматирование вывода
            String formattedEquation = sortedExpr.toString()
                    .replace("*", "") // Удаление знаков умножения
                    .replace(" ", ""); // Удаление пробелов

            // Разбивка уравнения на слагаемые
            List<String> terms = Arrays.asList(formattedEquation.split("(?=[+-])"));

            // Сортировка слагаемых в обратном порядке (по возрастанию степени)
            terms.sort(Comparator.comparingInt(this::getDegree).reversed());

            // Сборка уравнения из отсортированных слагаемых, добавление знак "+" перед положительными
            String sortedEquation = terms.stream()
                    .map(term -> term.startsWith("+") || term.startsWith("-") ? term : "+" + term)
                    .collect(Collectors.joining());

            // Удаление знака "+" перед высшей степенью, если он есть
            if (sortedEquation.startsWith("+")) {
                sortedEquation = sortedEquation.substring(1);
            }

            // Если перед высшей степенью "-", замена всех знаков "+" и "-" на противоположные
            if (sortedEquation.startsWith("-")) {
                sortedEquation = sortedEquation.replace("+", "temp")
                        .replace("-", "+")
                        .replace("temp", "-");
                sortedEquation = sortedEquation.substring(1); // Убираем первый "-"
            }

            // Форматирование коэффициентов
            sortedEquation = formatCoefficients(sortedEquation);

            // Возвращение результата в виде строки
            return sortedEquation + " = 0";
        } catch (Exception e) {
            throw new IllegalArgumentException("Уравнение введено некорректно: " + e.getMessage());
        }
    }

    // Метод для форматирования коэффициентов
    private String formatCoefficients(String equation) {
        // Регулярное выражение для поиска коэффициентов с плавающей точкой
        String regex = "(?<!\\^)([+-]?\\d+\\.\\d{3,})";
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex);
        java.util.regex.Matcher matcher = pattern.matcher(equation);

        // Список для хранения коэффициентов
        List<String> coefficients = new ArrayList<>();

        // Поиск и замена коэффициентов
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String coefficient = matcher.group(1);
            // Удаление последнего символа
            String formattedCoefficient = coefficient.substring(0, coefficient.length() - 1);
            // Удаление конечных нулей после точки
            formattedCoefficient = removeTrailingZeros(formattedCoefficient);
            // Обработка последовательности девяток
            formattedCoefficient = processNines(formattedCoefficient);
            coefficients.add(formattedCoefficient);
            // Замена коэффициентов на плейсхолдеры [1], [2] и т.д
            matcher.appendReplacement(result, "[" + (coefficients.size() - 1) + "]");
        }
        matcher.appendTail(result);

        // Восстановление коэффициентов на местах плейсхолдеров
        String formattedEquation = result.toString();
        for (int i = 0; i < coefficients.size(); i++) {
            formattedEquation = formattedEquation.replace("[" + i + "]", coefficients.get(i));
        }

        return formattedEquation;
    }

    // Метод для удаления конечных нулей после точки
    private String removeTrailingZeros(String number) {
        if (number.contains(".")) {
            // Удаление всех конечных нулей после точки
            number = number.replaceAll("0+$", "");
            // Если после удаления нулей осталась только точка, удаляется и она
            if (number.endsWith(".")) {
                number = number.substring(0, number.length() - 1);
            }
        }
        return number;
    }

    // Метод для обработки последовательностей девяток
    private String processNines(String number) {
        // Проверка, содержит ли число последовательность девяток в конце
        if (number.matches(".*9+$")) {
            // Нахождение индекса начала последовательности девяток
            int lastNonNineIndex = -1;
            for (int i = number.length() - 1; i >= 0; i--) {
                if (number.charAt(i) != '9') {
                    lastNonNineIndex = i;
                    break;
                }
            }

            // Если все символы — девятки, добавление "1" в начало
            if (lastNonNineIndex == -1) {
                number = "1" + number.replaceAll("9", "0");
            } else {
                // Увеличение цифры перед последовательностью девяток на 1
                char[] chars = number.toCharArray();
                chars[lastNonNineIndex] = (char) (chars[lastNonNineIndex] + 1);
                // Замена всех девяток на нули
                for (int i = lastNonNineIndex + 1; i < chars.length; i++) {
                    chars[i] = '0';
                }
                number = new String(chars);
            }

            // Удаление конечных нулей после точки, если они есть
            number = removeTrailingZeros(number);
        }
        return number;
    }

    // Метод для определения степени: @param term - слагаемое в виде строки; @return степень слагаемого.
    private int getDegree(String term) {
        if (term.contains("x^")) {
            return Integer.parseInt(term.split("x\\^")[1]);
        } else if (term.contains("x")) {
            return 1;
        } else {
            return 0;
        }
    }
}