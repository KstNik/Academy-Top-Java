package com.example.algebraicequation.service;

import org.apache.commons.math3.complex.Complex;
import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;
import org.apache.commons.math3.analysis.solvers.LaguerreSolver;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

@Service
public class EquationSolver {

    public List<String> solveEquation(int degree, double[] coefficients, int precision) {
        PolynomialFunction polynomial = new PolynomialFunction(coefficients);
        LaguerreSolver solver = new LaguerreSolver();
        Complex[] roots = solver.solveAllComplex(polynomial.getCoefficients(), 0);

        DecimalFormat df = new DecimalFormat("#." + "#".repeat(precision));
        df.setRoundingMode(RoundingMode.HALF_UP);

        List<String> result = new ArrayList<>();
        for (Complex root : roots) {
            String realPart = df.format(root.getReal());
            String imaginaryPart = df.format(root.getImaginary());
            result.add(realPart + (root.getImaginary() != 0 ? " + " + imaginaryPart + "i" : ""));
        }
        return result;
    }
}