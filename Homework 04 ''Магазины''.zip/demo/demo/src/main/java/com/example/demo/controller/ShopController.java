package com.example.demo.controller;

import com.example.demo.model.Shop;
import com.example.demo.repository.ShopRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/shops")
public class ShopController {
    private final ShopRepository shopRepository;

    public ShopController(ShopRepository shopRepository) {
        this.shopRepository = shopRepository;
    }

    @GetMapping
    public String listShops(Model model) {
        model.addAttribute("shops", shopRepository.findAll());
        return "shop/list";
    }

    @GetMapping("/new")
    public String newShopForm(Model model) {
        model.addAttribute("shop", new Shop());
        return "shop/form";
    }

    @PostMapping
    public String saveShop(@ModelAttribute Shop shop) {
        shopRepository.save(shop);
        return "redirect:/shops";
    }

    @GetMapping("/{id}")
    public String viewShop(@PathVariable Long id, Model model) {
        model.addAttribute("shop", shopRepository.findById(id).orElseThrow());
        return "shop/view";
    }

    @GetMapping("/{id}/edit")
    public String editShopForm(@PathVariable Long id, Model model) {
        model.addAttribute("shop", shopRepository.findById(id).orElseThrow());
        return "shop/form";
    }

    @PostMapping("/{id}")
    public String updateShop(@PathVariable Long id, @ModelAttribute Shop shop) {
        shop.setId(id);
        shopRepository.save(shop);
        return "redirect:/shops";
    }

    @PostMapping("/{id}/delete")
    public String deleteShop(@PathVariable Long id) {
        shopRepository.deleteById(id);
        return "redirect:/shops";
    }

    @GetMapping("/search")
    public String searchShops(@RequestParam String query, Model model) {
        List<Shop> result = shopRepository.findByNameContainingIgnoreCase(query);
        result.addAll(shopRepository.findByCategoryContainingIgnoreCase(query));
        result.addAll(shopRepository.findByAddressContainingIgnoreCase(query));
        model.addAttribute("shops", result);
        return "shop/list";
    }
}