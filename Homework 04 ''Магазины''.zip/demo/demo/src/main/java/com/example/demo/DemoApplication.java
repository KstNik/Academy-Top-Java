package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {
	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
}

// При создании проекта на сайте https://start.spring.io добавлены зависимости (кнопка ADD DEPENDENCIES): Sprint Web, Thimeleaf, Spring Data JPA (работа с базой данных) и H2 Database (для встроенной базы данных)
/*В resources/application.properties добавлен код настройки базы данных и H2-консоли:
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=password
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console*/

// Для запуска приложения набрать в адресной строке браузера: localhost:8080/shops

/*Задание 1. Используя Spring MVC создайте приложение «Магазины». Приложение должно позволять добавлять информацию о магазинах. Для каждого магазина необходимо хранить такую информацию:
- Название магазина;
- Адрес;
- Телефон;
- Email;
- Ссылка на сайт;
- Категория магазина (продовольственный, хозяйственный, спортивный и т.д.);
- Описание магазина.
Информация о добавленных магазинах отображается в списке. В списке необходимо отображать только часть информации. При клике по конкретному магазину нужно переходить на страницу с отображением полной информации о выбранном магазине.

Задание 2. Добавьте к первому заданию возможность редактирования существующих данных. После выбора конкретного магазина можно отредактировать информацию о нём. Обновлённую информацию нужно отобразить в списке.

Задание 3. Добавьте ко второму заданию возможность удаления данных. Пользователь может удалить информацию о конкретном магазине. После удаления нужно обновить информацию в списке.

Задание 4. Добавьте к третьему заданию возможность поиска информации о магазине по названию, категории, адресу. Пользователь вводит текст запроса в текстовое поле. Приложение должно отобразить магазины, чьи данные соответствуют поисковому запросу.*/