package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }

    @GetMapping("/{id}")
    public Optional<Book> getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        return bookService.saveBook(book);
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        return bookService.getBookById(id)
                .map(book -> {
                    book.setTitle(updatedBook.getTitle());
                    book.setAuthor(updatedBook.getAuthor());
                    book.setReleaseYear(updatedBook.getReleaseYear());
                    book.setGenre(updatedBook.getGenre());
                    book.setPages(updatedBook.getPages());
                    book.setDescription(updatedBook.getDescription());
                    return bookService.saveBook(book);
                }).orElseThrow(() -> new RuntimeException("Книга не найдена!"));
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
    }

    @GetMapping("/search")
    public List<Book> searchBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author,
            @RequestParam(required = false) Integer releaseYear,
            @RequestParam(required = false) String genre,
            @RequestParam(required = false) Integer pages,
            @RequestParam(required = false) String keyword) {
        return bookService.searchBooks(title, author, releaseYear, genre, pages, keyword);
    }

    // Добавление книги
    @GetMapping("/add")
    public String addBook(
            @RequestParam String title,
            @RequestParam String author,
            @RequestParam int releaseYear,
            @RequestParam String genre,
            @RequestParam int pages,
            @RequestParam String description) {
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setReleaseYear(releaseYear);
        book.setGenre(genre);
        book.setPages(pages);
        book.setDescription(description);
        bookService.saveBook(book);
        return "Книга добавлена успешно!";
    }

    // Изменение книги
    @GetMapping("/update")
    public String updateBook(
            @RequestParam Long id,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author,
            @RequestParam(required = false) String description) {
        return bookService.getBookById(id)
                .map(book -> {
                    if (title != null) book.setTitle(title);
                    if (author != null) book.setAuthor(author);
                    if (description != null) book.setDescription(description);
                    bookService.saveBook(book);
                    return "Книга успешно обновлена!";
                }).orElse("Книга с ID " + id + " не найдена!");
    }

    // Удаление книги
    @GetMapping("/delete")
    public String deleteBookById(@RequestParam Long id) {
        bookService.deleteBook(id);
        return "Книга с ID " + id + " успешно удалена!";
    }
}