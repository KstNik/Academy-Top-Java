package com.example.demo.service;

import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Optional<Book> getBookById(Long id) {
        return bookRepository.findById(id);
    }

    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }

    public List<Book> searchBooks(String title, String author, Integer releaseYear, String genre, Integer pages, String keyword) {
        // Комбинированный поиск
        if (title != null) return bookRepository.findByTitleContainingIgnoreCase(title);
        if (author != null) return bookRepository.findByAuthorContainingIgnoreCase(author);
        if (releaseYear != null) return bookRepository.findByReleaseYear(releaseYear);
        if (genre != null) return bookRepository.findByGenreContainingIgnoreCase(genre);
        if (pages != null) return bookRepository.findByPages(pages);
        if (keyword != null) return bookRepository.findByDescriptionContainingIgnoreCase(keyword);
        return List.of();
    }
}