package com.example.demo.repository;

import com.example.demo.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    // Дополнительные методы поиска
    List<Book> findByTitleContainingIgnoreCase(String title);
    List<Book> findByAuthorContainingIgnoreCase(String author);
    List<Book> findByReleaseYear(int releaseYear);
    List<Book> findByGenreContainingIgnoreCase(String genre);
    List<Book> findByPages(int pages);
    List<Book> findByDescriptionContainingIgnoreCase(String keyword);
}